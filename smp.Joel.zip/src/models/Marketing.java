
package models;

import java.util.ArrayList;
import utilities.GenderType;

public class Marketing extends Employee {
    //TODO
    private final ArrayList<String> ListOfCustomers = new ArrayList<>();
    private static int budget;

    public Marketing(double salary, String name, String birthdate, GenderType gender) {
        super(salary, name, birthdate, gender);
    }
    
    @Override
    public double bonus(){
        double bonus = employeeBonusBase + 300 * ListOfCustomers.size();
        return bonus;
    }

    public ArrayList<String> getListOfCustomers() {
        return ListOfCustomers;
    }
    public static int getBudget() {
        return budget;
    }

    public static void setBudget(int aBudget) {
        budget = aBudget;
    }

    @Override
    public String toString() {
        return super.toString() + "               Department: Marketing\n";
    }
    
    
    
}
