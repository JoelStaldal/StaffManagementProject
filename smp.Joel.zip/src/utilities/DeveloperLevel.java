
package utilities;

public enum DeveloperLevel {
    JUNIOR, SENIOR;
}
