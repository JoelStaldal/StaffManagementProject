
package utilities;

public enum GenderType {
    MALE, FEMALE, UNKNOWN;
}

